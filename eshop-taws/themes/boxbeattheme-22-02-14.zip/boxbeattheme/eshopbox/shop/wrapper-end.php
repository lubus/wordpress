<?php
/**
 * Content wrappers
 *
 * @author 		WooThemes
 * @package 	EshopBox/Templates
 * @version     1.6.4
 */
?>
	</div>
</div>